export default {
  "port": 3005
  "mongoUrl": "mongodb://localhost:27017/restaurant-api"
}
